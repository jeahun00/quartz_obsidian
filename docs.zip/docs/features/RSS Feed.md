Quartz emits an RSS feed for all the content on your site by generating an `index.xml` file that RSS readers can subscribe to. Because of the RSS spec, this requires the `baseUrl` property in your [[configuration]] to be set properly for RSS readers to pick it up properly.

## Configuration

This functionality is provided by the [[ContentIndex]] plugin. See the plugin page for customization options.
